# Extra strings
These are some extra string that exist in visuals or outside of the app (screenshots)

one two, mic. check, one two, mic. check = Eins, zwei, Mikrofon. Check. Eins, zwei, Mikrofon. Check.
